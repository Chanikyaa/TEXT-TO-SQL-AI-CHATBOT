"""Orchestrates schema grounding, SQL validation, execution and concise result summaries."""
from .validation import validate_select
from .database import Database
from .generator import MockSQLGenerator

class TextToSQLService:
    def __init__(self, database: Database, generator=None, max_rows=200):
        self.database=database
        self.generator=generator or MockSQLGenerator()
        self.max_rows=max_rows
    def ask(self, question: str, history=None) -> dict:
        schema=self.database.schema_description()
        raw=self.generator.generate(question,schema,history)
        sql=validate_select(raw)
        rows=self.database.execute_readonly(sql,self.max_rows)
        return {"question":question,"sql":sql,"rows":rows,"row_count":len(rows),
                "summary":f"Query returned {len(rows)} row(s)."}
