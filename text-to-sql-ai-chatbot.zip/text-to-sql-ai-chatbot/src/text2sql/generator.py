"""LLM SQL generator interface and deterministic demo generator."""
import os, requests

class SQLGenerator:
    def generate(self, question: str, schema: str, history: list[dict] | None = None) -> str:
        raise NotImplementedError

class MockSQLGenerator(SQLGenerator):
    def generate(self, question: str, schema: str, history=None) -> str:
        q=question.lower()
        if "department" in q and "employee" in q:
            return "SELECT department, COUNT(*) AS employee_count FROM employees GROUP BY department ORDER BY employee_count DESC LIMIT 200"
        if "employee" in q or "salary" in q:
            return "SELECT id, name, department, salary FROM employees ORDER BY salary DESC LIMIT 200"
        return "SELECT id, name, department, salary FROM employees LIMIT 200"

class OpenAICompatibleSQLGenerator(SQLGenerator):
    def __init__(self, api_key=None, base_url=None, model=None):
        self.api_key=api_key or os.getenv("OPENAI_API_KEY","")
        self.base_url=(base_url or os.getenv("OPENAI_BASE_URL","https://api.openai.com/v1")).rstrip("/")
        self.model=model or os.getenv("OPENAI_MODEL","gpt-4o-mini")
    def generate(self, question, schema, history=None):
        if not self.api_key: raise RuntimeError("OPENAI_API_KEY is required.")
        system=("Generate exactly one read-only SQLite SELECT statement. Use only the schema below. "
                "No markdown, comments, DDL, DML, or explanations. Never request credentials.\n"+schema)
        messages=[{"role":"system","content":system}]
        for item in (history or [])[-4:]:
            if item.get("role") in ("user","assistant"):
                messages.append({"role":item["role"],"content":str(item.get("content",""))[:2000]})
        messages.append({"role":"user","content":question})
        r=requests.post(self.base_url+"/chat/completions",
            headers={"Authorization":f"Bearer {self.api_key}"},
            json={"model":self.model,"messages":messages,"temperature":0},timeout=60)
        r.raise_for_status()
        return r.json()["choices"][0]["message"]["content"].strip().strip("`")
