from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from .config import Settings
from .database import Database
from .service import TextToSQLService
from .generator import MockSQLGenerator, OpenAICompatibleSQLGenerator

settings=Settings()
db=Database(settings.database_url)
generator=OpenAICompatibleSQLGenerator() if settings.openai_api_key else MockSQLGenerator()
service=TextToSQLService(db,generator,settings.max_rows)
app=FastAPI(title="Text-to-SQL Assistant",version="0.1.0")

class AskRequest(BaseModel):
    question: str = Field(min_length=3,max_length=2000)
    history: list[dict] = Field(default_factory=list)

@app.get("/health")
def health(): return {"status":"ok"}

@app.get("/schema")
def schema(): return {"schema":db.schema_description()}

@app.post("/ask")
def ask(request: AskRequest):
    try: return service.ask(request.question,request.history)
    except Exception as exc: raise HTTPException(status_code=400,detail=str(exc)) from exc
