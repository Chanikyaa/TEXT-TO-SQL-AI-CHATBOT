"""SQLAlchemy connection, schema discovery and read-only query execution."""
from sqlalchemy import create_engine, inspect, text
from sqlalchemy.exc import SQLAlchemyError

class Database:
    def __init__(self, url: str):
        self.engine = create_engine(url, future=True)
    def schema_description(self) -> str:
        inspector=inspect(self.engine); chunks=[]
        for table in inspector.get_table_names():
            cols=inspector.get_columns(table)
            names=", ".join(f"{c['name']} ({c['type']})" for c in cols)
            chunks.append(f"Table {table}: {names}")
            for fk in inspector.get_foreign_keys(table):
                chunks.append(f"Foreign key {table}.{','.join(fk['constrained_columns'])} -> "
                              f"{fk['referred_table']}.{','.join(fk['referred_columns'])}")
        return "\n".join(chunks)
    def execute_readonly(self, sql: str, max_rows: int = 200) -> list[dict]:
        with self.engine.connect() as conn:
            if self.engine.dialect.name == "sqlite":
                conn.exec_driver_sql("PRAGMA query_only = ON")
            result=conn.execute(text(sql))
            if not result.returns_rows: raise ValueError("Only row-returning queries are permitted.")
            return [dict(row._mapping) for row in result.fetchmany(max_rows)]
