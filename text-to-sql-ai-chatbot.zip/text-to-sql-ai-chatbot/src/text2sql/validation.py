"""Fail-closed SQL validation. sqlglot parses one statement and checks its AST."""
import re
import sqlglot
from sqlglot import exp

class SQLValidationError(ValueError): pass

def validate_select(sql: str) -> str:
    candidate=sql.strip().rstrip(";").strip()
    if not candidate: raise SQLValidationError("SQL query is empty.")
    if re.search(r"--|/\\*|\\*/", candidate):
        raise SQLValidationError("SQL comments are not accepted.")
    try:
        statements=sqlglot.parse(candidate, read="sqlite")
    except sqlglot.errors.ParseError as exc:
        raise SQLValidationError(f"SQL parse error: {exc}") from exc
    if len(statements) != 1 or not isinstance(statements[0], exp.Select):
        raise SQLValidationError("Only a single SELECT query is allowed.")
    tree=statements[0]
    if tree.find(exp.Select) is None:
        raise SQLValidationError("SELECT required.")
    forbidden=(exp.Insert,exp.Update,exp.Delete,exp.Drop,exp.Alter,exp.Create,
               exp.Command,exp.Merge,exp.TruncateTable,exp.Transaction)
    if any(tree.find(kind) is not None for kind in forbidden):
        raise SQLValidationError("Destructive or mutating SQL is not allowed.")
    if tree.find(exp.Limit) is None:
        tree=tree.limit(200)
    return tree.sql(dialect="sqlite")
