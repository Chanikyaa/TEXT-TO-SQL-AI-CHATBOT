import streamlit as st
import pandas as pd
import plotly.express as px
from text2sql.config import Settings
from text2sql.database import Database
from text2sql.service import TextToSQLService
from text2sql.generator import MockSQLGenerator, OpenAICompatibleSQLGenerator

st.set_page_config(page_title="Ask Your Data",layout="wide")
st.title("Ask Your Data")
st.caption("Natural language → validated read-only SQL → results")
settings=Settings()
@st.cache_resource
def get_service():
    db=Database(settings.database_url)
    gen=OpenAICompatibleSQLGenerator() if settings.openai_api_key else MockSQLGenerator()
    return TextToSQLService(db,gen,settings.max_rows)
service=get_service()
with st.sidebar:
    st.subheader("Database schema")
    st.code(service.database.schema_description() or "No tables found.")
    st.caption("Demo defaults to SQLite. Configure DATABASE_URL for PostgreSQL.")
question=st.chat_input("Ask a question about the sample employees data…")
if "history" not in st.session_state: st.session_state.history=[]
for item in st.session_state.history:
    with st.chat_message(item["role"]): st.write(item["content"])
if question:
    st.session_state.history.append({"role":"user","content":question})
    with st.chat_message("user"): st.write(question)
    with st.chat_message("assistant"):
        try:
            result=service.ask(question,st.session_state.history[:-1])
            st.code(result["sql"],language="sql")
            frame=pd.DataFrame(result["rows"])
            st.dataframe(frame,use_container_width=True)
            st.write(result["summary"])
            numeric=[c for c in frame.columns if pd.api.types.is_numeric_dtype(frame[c])]
            if len(frame) and numeric and len(frame.columns)>1:
                x=next((c for c in frame.columns if c not in numeric),frame.columns[0])
                st.plotly_chart(px.bar(frame,x=x,y=numeric[0],title=f"{numeric[0]} by {x}"),use_container_width=True)
            st.session_state.history.append({"role":"assistant","content":result["summary"]})
        except Exception as exc: st.error(f"Could not answer safely: {exc}")
