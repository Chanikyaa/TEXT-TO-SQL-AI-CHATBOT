# Security Policy

Do not report vulnerabilities in public issues. Contact the repository maintainer privately.
Never use production credentials in tests. Treat model output, repository content, and SQL
input as untrusted. See the project documentation for the relevant isolation boundaries.
