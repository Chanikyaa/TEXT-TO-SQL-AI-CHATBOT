# Architecture

A schema-aware read-only text-to-SQL chatbot with API and Streamlit UI.

The application separates domain logic, provider integrations, interfaces, and persistence.
Provider-specific code is isolated behind small interfaces so deterministic local tests do not
need external services.
