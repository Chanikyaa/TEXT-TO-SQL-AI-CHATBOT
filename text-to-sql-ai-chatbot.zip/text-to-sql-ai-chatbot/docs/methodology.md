# SQL safety and evaluation methodology

The service discovers table/column names and foreign keys through SQLAlchemy inspection, places
schema text in the generation prompt, parses model output with SQLGlot, accepts one SELECT AST,
adds a default row limit, and executes through SQLAlchemy. SQLite connections are placed in
`PRAGMA query_only=ON` before execution. For PostgreSQL deployments, use a dedicated database
principal granted SELECT only; application-level SQL parsing is not a substitute for database
permissions, statement timeouts, network controls or resource governance.

The bundled benchmark examples are reference prompts, not a measured accuracy score. Evaluate
with exact-match and execution accuracy on a held-out dataset, manually inspect ambiguous queries,
and report invalid-query rate, latency and result correctness. The mock generator is deterministic
and intended only to demonstrate end-to-end mechanics.
