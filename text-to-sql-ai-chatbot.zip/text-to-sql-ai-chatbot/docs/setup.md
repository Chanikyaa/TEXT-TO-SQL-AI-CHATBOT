Initialize the demo database with `python scripts/init_db.py`; see README for Streamlit and API commands.
