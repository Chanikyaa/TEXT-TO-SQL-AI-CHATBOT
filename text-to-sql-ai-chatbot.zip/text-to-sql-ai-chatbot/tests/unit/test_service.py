from sqlalchemy import create_engine, text
from text2sql.database import Database
from text2sql.service import TextToSQLService
from text2sql.generator import MockSQLGenerator

def test_service_executes_sample_select(tmp_path):
    dbpath=tmp_path/"test.db"
    engine=create_engine(f"sqlite:///{dbpath}")
    with engine.begin() as conn:
        conn.execute(text("CREATE TABLE employees (id INTEGER, name TEXT, department TEXT, salary INTEGER)"))
        conn.execute(text("INSERT INTO employees VALUES (1,'Ada','Eng',100)"))
    service=TextToSQLService(Database(f"sqlite:///{dbpath}"),MockSQLGenerator())
    result=service.ask("show employees")
    assert result["row_count"] == 1
    assert result["rows"][0]["name"] == "Ada"
