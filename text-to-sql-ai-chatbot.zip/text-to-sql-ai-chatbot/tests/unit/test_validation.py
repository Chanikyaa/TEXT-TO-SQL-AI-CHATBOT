import pytest
from text2sql.validation import validate_select, SQLValidationError

def test_select_allowed_and_limited():
    sql=validate_select("SELECT name FROM employees")
    assert "LIMIT" in sql.upper()

@pytest.mark.parametrize("sql",[
    "DELETE FROM employees","DROP TABLE employees","UPDATE employees SET salary=0",
    "SELECT 1; DELETE FROM employees",""
])
def test_mutations_and_multiple_statements_rejected(sql):
    with pytest.raises(SQLValidationError): validate_select(sql)
