from sqlalchemy import create_engine, text
from text2sql.config import Settings

engine=create_engine(Settings().database_url)
with engine.begin() as conn:
    conn.execute(text("""CREATE TABLE IF NOT EXISTS employees (
        id INTEGER PRIMARY KEY, name TEXT NOT NULL, department TEXT NOT NULL, salary INTEGER NOT NULL
    )"""))
    count=conn.execute(text("SELECT COUNT(*) FROM employees")).scalar_one()
    if count == 0:
        conn.execute(text("""INSERT INTO employees (id,name,department,salary) VALUES
            (1,'Asha','Engineering',120000),(2,'Ravi','Engineering',110000),
            (3,'Mina','Sales',90000),(4,'Noah','Sales',95000),
            (5,'Isha','Finance',105000)"""))
print("Sample database initialized.")
