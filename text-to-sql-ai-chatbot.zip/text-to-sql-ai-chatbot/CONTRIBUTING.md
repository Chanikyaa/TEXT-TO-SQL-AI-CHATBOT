# Contributing

1. Open an issue describing the bug or proposed change.
2. Create a focused branch and add or update tests.
3. Run `pytest` and `ruff check src tests`.
4. Submit a pull request with motivation, implementation notes, and validation output.

Please avoid committing credentials, private datasets, generated model weights, or user data.
