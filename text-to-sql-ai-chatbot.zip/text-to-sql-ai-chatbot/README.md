# Text-to-SQL AI Chatbot

A schema-aware conversational assistant that converts natural-language questions into SQL,
validates generated SQL, executes read-only queries through SQLAlchemy and presents results through
FastAPI and Streamlit.

## Problem and motivation
Business users often need data but do not know SQL. A safe text-to-SQL workflow must ground
generation in the live schema, validate the query before execution and make the SQL inspectable.

## Features
- SQLite demo database and PostgreSQL URL support.
- Automatic table, column and foreign-key discovery.
- Mock generator for offline use; OpenAI-compatible generator for real model calls.
- SQLGlot AST validation: one SELECT statement only, comments and mutations rejected.
- SQLAlchemy execution, result caps, query history in the UI and automatic chart suggestion.
- FastAPI `/health`, `/schema` and `/ask` endpoints.

## Architecture
```mermaid
flowchart LR
 Q[User question + short history] --> G[LLM SQL generator]
 S[SQLAlchemy schema inspector] --> G
 G --> V[SQLGlot SELECT validator]
 V --> DB[Read-only database execution]
 DB --> R[Rows + SQL + summary]
 R --> UI[Streamlit] 
 R --> API[FastAPI]
```

## Stack
Python, FastAPI, Streamlit, SQLAlchemy, SQLite/PostgreSQL, Pandas, Pydantic, SQLGlot, Plotly, pytest.

## Install and run
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
pip install -e .
python scripts/init_db.py
streamlit run app.py
```
Start API separately:
```bash
uvicorn text2sql.api:app --app-dir src --reload
```
Set `DATABASE_URL` to a PostgreSQL SQLAlchemy URL and provide the PostgreSQL driver (for example
`psycopg[binary]`) when deploying to PostgreSQL. Use a read-only database user. For model-backed
generation, set `OPENAI_API_KEY`, `OPENAI_BASE_URL` and `OPENAI_MODEL`; without a key the app uses
the deterministic mock generator.

## Example
Try `Show all employees by salary` or `Count employees by department`. Inspect the generated SQL
before trusting results. The mock generator maps a small set of demo intents; arbitrary language
coverage requires a configured LLM.

## Evaluation
See [docs/methodology.md](docs/methodology.md). No accuracy benchmark is claimed from the sample
fixtures. Measure execution accuracy on a held-out set and review outputs with domain experts.

## Limitations and safety
- SQL parser validation is defense in depth, not a security boundary.
- SQLite query-only mode is connection-local; use a least-privilege DB role for PostgreSQL.
- Query timeout enforcement is deployment/database specific and must be configured at the server.
- Mock generation handles only a few demonstration intents.
- Follow-up context is bounded and should be treated as untrusted input.

## Future improvements
Add dialect-aware prompts, parameter extraction, database-specific statement timeouts, query
caching, semantic result summaries, richer chart selection and benchmark harnesses.

## Contributing, security and license
See [CONTRIBUTING.md](CONTRIBUTING.md), [SECURITY.md](SECURITY.md), and [LICENSE](LICENSE).

GitHub topics: `text-to-sql`, `llm`, `fastapi`, `streamlit`, `sqlalchemy`.
